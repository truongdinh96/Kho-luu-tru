module.exports.register = function (Handlebars, options)  { 
  // Handlebars.registerHelper('isActive', function (dest, pageName)  { 
  //   var a = dest;
  //   var b = pageName;

  //   if(a.indexOf(b) > -1){
  //   	return 'class="active"'
  // 	} else {
  	
  // 	}
    
  // });
};